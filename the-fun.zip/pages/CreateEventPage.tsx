
import React, { useState } from 'react';
import { AIIdeaGenerator } from '../components/AIIdeaGenerator';
import { EventCategory, GenderRatio } from '../types';

export const CreateEventPage: React.FC = () => {
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [category, setCategory] = useState<EventCategory>(EventCategory.PARTY);

    const handleSelectIdea = (idea: { title: string; description:string; category: string }) => {
        setTitle(idea.title);
        setDescription(idea.description);
        const ideaCategory = Object.values(EventCategory).find(c => c.toLowerCase() === idea.category.toLowerCase());
        if (ideaCategory) {
            setCategory(ideaCategory);
        }
    };
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        // Here you would handle form submission, e.g., send data to a backend
        alert('Event created successfully! (Simulation)');
    };

    return (
        <div className="p-4">
            <h1 className="text-2xl font-bold mb-4">Create an Event</h1>

            <AIIdeaGenerator onSelectIdea={handleSelectIdea} />

            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label htmlFor="title" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Title</label>
                    <input type="text" id="title" value={title} onChange={e => setTitle(e.target.value)} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-dark-surface border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-brand-purple focus:border-brand-purple" required />
                </div>
                <div>
                    <label htmlFor="description" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Description</label>
                    <textarea id="description" value={description} onChange={e => setDescription(e.target.value)} rows={3} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-dark-surface border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-brand-purple focus:border-brand-purple" required />
                </div>
                <div>
                    <label htmlFor="category" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Category</label>
                    <select id="category" value={category} onChange={e => setCategory(e.target.value as EventCategory)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-dark-surface border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-brand-purple focus:border-brand-purple sm:text-sm rounded-md">
                        {Object.values(EventCategory).map(cat => <option key={cat} value={cat}>{cat}</option>)}
                    </select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                     <div>
                        <label htmlFor="capacity" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Capacity</label>
                        <input type="number" id="capacity" defaultValue={10} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-dark-surface border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-brand-purple focus:border-brand-purple" />
                    </div>
                     <div>
                        <label htmlFor="genderRatio" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Guest Ratio</label>
                        <select id="genderRatio" defaultValue={GenderRatio.ANY} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-dark-surface border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-brand-purple focus:border-brand-purple sm:text-sm rounded-md">
                            {Object.values(GenderRatio).map(ratio => <option key={ratio} value={ratio}>{ratio}</option>)}
                        </select>
                    </div>
                </div>
                 <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Event Type</label>
                    <div className="mt-2 flex items-center space-x-4">
                       <label className="flex items-center">
                         <input type="radio" name="eventType" value="public" className="h-4 w-4 text-brand-purple border-gray-300 focus:ring-brand-purple" defaultChecked />
                         <span className="ml-2">Public</span>
                       </label>
                        <label className="flex items-center">
                         <input type="radio" name="eventType" value="private" className="h-4 w-4 text-brand-purple border-gray-300 focus:ring-brand-purple" />
                         <span className="ml-2">Private</span>
                       </label>
                    </div>
                </div>

                <button type="submit" className="w-full bg-brand-purple dark:bg-brand-teal text-white font-bold py-3 px-4 rounded-lg hover:opacity-90 transition-opacity">
                    Create Event
                </button>
            </form>
        </div>
    );
};
