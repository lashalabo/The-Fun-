
import React from 'react';
import { Icon } from '../components/Icon';

const EventPin: React.FC<{ top: string; left: string; }> = ({ top, left }) => {
    return (
        <div className="absolute -translate-x-1/2 -translate-y-1/2" style={{ top, left }}>
            <div className="group flex flex-col items-center cursor-pointer">
                 <div className="p-2 bg-brand-teal rounded-full shadow-[0_0_15px_3px_#4FD1C5]">
                    <Icon name="location" className="w-6 h-6 text-white"/>
                 </div>
                 <div className="w-2 h-2 bg-brand-teal/50 rounded-full animate-ping mt-1"></div>
            </div>
        </div>
    );
};


export const DiscoveryPage: React.FC = () => {
  return (
    <div className="w-full h-full bg-transparent">
      {/* View Mode Toggle */}
      <div className="fixed top-[72px] left-1/2 -translate-x-1/2 z-20">
         <div className="flex items-center bg-gray-200 dark:bg-dark-surface p-1 rounded-full shadow-md">
            <button
                className={`px-4 py-2 text-sm font-bold rounded-full transition-colors bg-brand-purple dark:bg-brand-teal text-white`}
            >
                <Icon name="map" className="w-5 h-5" />
            </button>
            <button
                className={`px-4 py-2 text-sm font-bold rounded-full transition-colors text-gray-700 dark:text-gray-300`}
            >
                <Icon name="list" className="w-5 h-5" />
            </button>
        </div>
      </div>
      
      {/* Event Pins */}
      <EventPin top="30%" left="30%" />
      <EventPin top="55%" left="65%" />
      <EventPin top="70%" left="25%" />
    </div>
  );
};
